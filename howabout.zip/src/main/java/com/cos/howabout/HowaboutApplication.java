package com.cos.howabout;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HowaboutApplication {

	public static void main(String[] args) {
		SpringApplication.run(HowaboutApplication.class, args);
	}

}
