package com.cos.howabout.comment;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface CommentRepository extends JpaRepository<Comment, Integer> {
		
	@Query(value ="SELECT * FROM comment WHERE post_id = :id",nativeQuery = true)
	List<Comment>mFindAllByPostId(int id);
	
	@Query(value ="SELECT * FROM comment WHERE after_id = :id",nativeQuery = true)
	List<Comment>mFindAllByAfterId(int id);
}
