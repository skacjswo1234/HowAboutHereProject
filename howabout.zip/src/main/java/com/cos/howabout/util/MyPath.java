package com.cos.howabout.util;

public class MyPath {
	
	public static String path = "C:/Users/90788/springtool/workspace/howabout/src/main/resources/static/upload/";
}
