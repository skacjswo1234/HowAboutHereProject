package com.cos.howabout.image;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RestImageRepository extends JpaRepository<RestImage, Integer>{

}
